def DLS(graph, start, goal, limit, path):

    if start == goal:
        return path

    if limit <= 0:
        return 'CUTOFF'

    cutoff = False

    for child in graph[start]:
        r = DLS(graph, child, goal, limit - 1, path + [child])

        if r == 'CUTOFF':
            cutoff = True

    return r if not cutoff else 'CUTOFF'


def IDDFS(graph, start, goal, max_depth):

    for d in range(max_depth + 1):

        r = DLS(graph, start, goal, d, [start])

        if r != 'CUTOFF':
            return r